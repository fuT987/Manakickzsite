
# MANA KICKS - Mini Site

Bienvenue sur le dépôt officiel du projet **MANA KICKS**.

## Structure :
- `mana-kicks.html` : page principale du site (Accueil, Boutique, Mana By You, À propos)
- `mana-custom-demo.html` : configurateur interactif pour personnaliser vos paires
- `base_shoe_model.png` : image de base pour les customisations

## Comment publier :
- Uploadez tous les fichiers dans un dépôt GitHub
- Activez GitHub Pages via Settings > Pages > Deploy from branch
- Votre site sera disponible à une adresse du type `https://votrenom.github.io/mana-kicks`

Merci de soutenir le mouvement MANA !
